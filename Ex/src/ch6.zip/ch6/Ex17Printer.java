package ch6;

public class Ex17Printer {
	static void Ex17Println(int a) {
		System.out.println(a);
	}
	static void Ex17Println(boolean a) {
		System.out.println(a);
	}
	static void Ex17Println(double a) {
		System.out.println(a);
	}
	static void Ex17Println(String a) {
		System.out.println(a);
	}
}
