package ch6;

public class Ex13Member {
	String name,id,password;
	int age;
	
	Ex13Member(String name,String id){
		this.name = name;
		this.id = id;	
	}
}
