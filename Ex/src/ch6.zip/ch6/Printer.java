package ch6;

public class Printer {
	
}
