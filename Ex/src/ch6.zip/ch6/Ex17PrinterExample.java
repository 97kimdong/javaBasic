package ch6;

public class Ex17PrinterExample {
	public static void main(String[] args) {
		Ex17Printer.Ex17Println(10);
		Ex17Printer.Ex17Println(true);
		Ex17Printer.Ex17Println(5.7);
		Ex17Printer.Ex17Println("홍길동");
	}
}
